[DEMO GIF](https://i.imgur.com/bLyjG9t.gif)

| Light  | Dark  |
| -----------------| -----|
| ![Light](https://i.imgur.com/XKCKrT8.png) | ![Dark](https://i.imgur.com/HT3ko7i.png) |
| ![Light](https://i.imgur.com/TPAc5lv.png) | ![Dark](https://i.imgur.com/1eIQ30v.png) |
| ![Light](https://i.imgur.com/2RwKb8y.png) | ![Dark](https://i.imgur.com/qQGUszi.png) |
| ![Light](https://i.imgur.com/kBrkscT.png) | ![Dark](https://i.imgur.com/9ByGECy.png) |
| ![Light](https://i.imgur.com/TrIMhYM.png) | ![Dark](https://i.imgur.com/1x2kkNa.png) |