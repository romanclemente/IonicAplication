import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-story-feedback',
  templateUrl: './story-feedback.component.html',
  styleUrls: ['./story-feedback.component.scss'],
})
export class StoryFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
