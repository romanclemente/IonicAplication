import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-related-you',
  templateUrl: './related-you.component.html',
  styleUrls: ['./related-you.component.scss'],
})
export class RelatedYouComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
