import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birthdays',
  templateUrl: './birthdays.component.html',
  styleUrls: ['./birthdays.component.scss'],
})
export class BirthdaysComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
