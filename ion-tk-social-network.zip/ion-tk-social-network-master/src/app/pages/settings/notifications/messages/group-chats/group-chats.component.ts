import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-chats',
  templateUrl: './group-chats.component.html',
  styleUrls: ['./group-chats.component.scss'],
})
export class GroupChatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
