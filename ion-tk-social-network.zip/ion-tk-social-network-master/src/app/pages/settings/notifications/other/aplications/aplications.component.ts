import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aplications',
  templateUrl: './aplications.component.html',
  styleUrls: ['./aplications.component.scss'],
})
export class AplicationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
