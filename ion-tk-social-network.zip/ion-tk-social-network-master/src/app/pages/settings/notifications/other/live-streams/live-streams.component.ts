import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-streams',
  templateUrl: './live-streams.component.html',
  styleUrls: ['./live-streams.component.scss'],
})
export class LiveStreamsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
