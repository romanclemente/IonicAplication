import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-messages',
  templateUrl: './company-messages.component.html',
  styleUrls: ['./company-messages.component.scss'],
})
export class CompanyMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
