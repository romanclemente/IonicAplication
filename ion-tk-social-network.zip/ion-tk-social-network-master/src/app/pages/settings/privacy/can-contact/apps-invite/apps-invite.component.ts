import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apps-invite',
  templateUrl: './apps-invite.component.html',
  styleUrls: ['./apps-invite.component.scss'],
})
export class AppsInviteComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
