import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-by-reg-phone',
  templateUrl: './search-by-reg-phone.component.html',
  styleUrls: ['./search-by-reg-phone.component.scss'],
})
export class SearchByRegPhoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
